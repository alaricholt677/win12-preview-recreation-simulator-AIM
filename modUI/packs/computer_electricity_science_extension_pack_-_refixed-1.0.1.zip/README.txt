Computer + Electricity + Science Extension Pack - Refixed
========================================================

This is the refixed zip version.

Fix:
- Entity custom cube arrays are placed before the template field.
- Template value is blocky_humanoid instead of custom.
- GenericModEntity will still use the custom mesh because customCubes is non-empty.

Expected logs:
- lab_assistant_bot customCubes=8
- electric_wisp customCubes=5
- data_drone customCubes=5
- quantum_scientist_hologram customCubes=7

Install:
  Put this zip in expansion_packs/ and remove the older computer_electricity_science_extension_pack.zip.

Upload path:
  modUI/packs/computer_electricity_science_extension_pack_refixed.zip

ui.store entry:
  {
    "name": "Computer + Electricity + Science Extension Pack - Refixed",
    "description": "Adds computers, electricity, science lab blocks, custom entities, recipes, commands, menus, and custom AI data. Refixed for custom model loading.",
    "url": "https://alaricholt677.github.io/modUI/packs/computer_electricity_science_extension_pack_refixed.zip"
  }
